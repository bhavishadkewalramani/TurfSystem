import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { User, Turf, Booking, Review } from '../types';
import { mockTurfs, mockUsers, mockBookings, mockReviews } from '../data/mockData';

interface AppState {
  user: User | null;
  turfs: Turf[];
  bookings: Booking[];
  reviews: Review[];
  darkMode: boolean;
}

type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_TURFS'; payload: Turf[] }
  | { type: 'ADD_TURF'; payload: Turf }
  | { type: 'UPDATE_TURF'; payload: Turf }
  | { type: 'SET_BOOKINGS'; payload: Booking[] }
  | { type: 'ADD_BOOKING'; payload: Booking }
  | { type: 'UPDATE_BOOKING'; payload: Booking }
  | { type: 'SET_REVIEWS'; payload: Review[] }
  | { type: 'ADD_REVIEW'; payload: Review }
  | { type: 'TOGGLE_DARK_MODE' };

const initialState: AppState = {
  user: null,
  turfs: mockTurfs,
  bookings: mockBookings,
  reviews: mockReviews,
  darkMode: false,
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_TURFS':
      return { ...state, turfs: action.payload };
    case 'ADD_TURF':
      return { ...state, turfs: [...state.turfs, action.payload] };
    case 'UPDATE_TURF':
      return {
        ...state,
        turfs: state.turfs.map(turf =>
          turf.id === action.payload.id ? action.payload : turf
        ),
      };
    case 'SET_BOOKINGS':
      return { ...state, bookings: action.payload };
    case 'ADD_BOOKING':
      return { ...state, bookings: [...state.bookings, action.payload] };
    case 'UPDATE_BOOKING':
      return {
        ...state,
        bookings: state.bookings.map(booking =>
          booking.id === action.payload.id ? action.payload : booking
        ),
      };
    case 'SET_REVIEWS':
      return { ...state, reviews: action.payload };
    case 'ADD_REVIEW':
      return { ...state, reviews: [...state.reviews, action.payload] };
    case 'TOGGLE_DARK_MODE':
      return { ...state, darkMode: !state.darkMode };
    default:
      return state;
  }
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Omit<User, 'id'>) => Promise<boolean>;
  logout: () => void;
}>({
  state: initialState,
  dispatch: () => {},
  login: async () => false,
  register: async () => false,
  logout: () => {},
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  useEffect(() => {
    // Load data from localStorage
    const savedUser = localStorage.getItem('turfUser');
    const savedDarkMode = localStorage.getItem('turfDarkMode');
    
    if (savedUser) {
      dispatch({ type: 'SET_USER', payload: JSON.parse(savedUser) });
    }
    
    if (savedDarkMode) {
      dispatch({ type: 'TOGGLE_DARK_MODE' });
    }
  }, []);

  useEffect(() => {
    // Save user to localStorage
    if (state.user) {
      localStorage.setItem('turfUser', JSON.stringify(state.user));
    } else {
      localStorage.removeItem('turfUser');
    }
  }, [state.user]);

  useEffect(() => {
    // Apply dark mode
    if (state.darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('turfDarkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.removeItem('turfDarkMode');
    }
  }, [state.darkMode]);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock authentication
    const user = mockUsers.find(u => u.email === email);
    if (user) {
      dispatch({ type: 'SET_USER', payload: user });
      return true;
    }
    return false;
  };

  const register = async (userData: Omit<User, 'id'>): Promise<boolean> => {
    // Mock registration
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
    };
    dispatch({ type: 'SET_USER', payload: newUser });
    return true;
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
  };

  return (
    <AppContext.Provider value={{ state, dispatch, login, register, logout }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};