import { User, Turf, Booking, Review } from '../types';

export const mockUsers: User[] = [
  {
    id: '1',
    email: 'player@example.com',
    name: 'John Doe',
    phone: '+91 9876543210',
    role: 'player',
  },
  {
    id: '2',
    email: 'owner@example.com',
    name: 'Sarah Wilson',
    phone: '+91 9876543211',
    role: 'owner',
  },
];

export const mockTurfs: Turf[] = [
  {
    id: '1',
    name: 'Green Valley Sports Complex',
    location: 'Bangalore, Karnataka',
    description: 'Premium quality artificial turf with floodlights and modern facilities.',
    images: [
      'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg',
      'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg',
      'https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg'
    ],
    sports: ['Football', 'Cricket'],
    amenities: ['Parking', 'Changing Room', 'Washroom', 'Floodlights', 'Water'],
    pricePerHour: 1500,
    availableHours: { start: '06:00', end: '23:00' },
    rating: 4.5,
    totalReviews: 128,
    ownerId: '2',
    equipmentRental: {
      available: true,
      items: [
        { id: '1', name: 'Football', price: 50, available: 10 },
        { id: '2', name: 'Cricket Kit', price: 200, available: 5 },
        { id: '3', name: 'Goalkeeper Gloves', price: 100, available: 8 }
      ]
    },
    events: [
      {
        id: '1',
        title: 'Weekend Football Tournament',
        date: '2025-02-15',
        description: 'Join our exciting weekend tournament with prizes!',
        price: 500
      }
    ]
  },
  {
    id: '2',
    name: 'Champions League Turf',
    location: 'Mumbai, Maharashtra',
    description: 'Professional grade turf perfect for competitive matches.',
    images: [
      'https://images.pexels.com/photos/399187/pexels-photo-399187.jpeg',
      'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg'
    ],
    sports: ['Football', 'Basketball'],
    amenities: ['Parking', 'Changing Room', 'First Aid', 'Floodlights', 'Cafeteria'],
    pricePerHour: 2000,
    availableHours: { start: '05:00', end: '24:00' },
    rating: 4.8,
    totalReviews: 89,
    ownerId: '2',
    equipmentRental: {
      available: true,
      items: [
        { id: '4', name: 'Basketball', price: 75, available: 6 },
        { id: '5', name: 'Football Boots', price: 300, available: 12 }
      ]
    },
    events: [
      {
        id: '2',
        title: 'Basketball Championship',
        date: '2025-02-20',
        description: 'Monthly basketball tournament for all skill levels.',
        price: 300
      }
    ]
  },
  {
    id: '3',
    name: 'Sports Arena 360',
    location: 'Delhi, NCR',
    description: 'Multi-sport facility with state-of-the-art equipment and amenities.',
    images: [
      'https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg',
      'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg'
    ],
    sports: ['Football', 'Cricket', 'Badminton'],
    amenities: ['Parking', 'Changing Room', 'Washroom', 'Floodlights', 'AC Rooms', 'Cafeteria'],
    pricePerHour: 1800,
    availableHours: { start: '06:00', end: '22:00' },
    rating: 4.6,
    totalReviews: 156,
    ownerId: '2',
    equipmentRental: {
      available: true,
      items: [
        { id: '6', name: 'Badminton Racket', price: 150, available: 15 },
        { id: '7', name: 'Shuttlecock Set', price: 80, available: 20 }
      ]
    },
    events: []
  }
];

export const mockBookings: Booking[] = [
  {
    id: '1',
    turfId: '1',
    userId: '1',
    date: '2025-01-20',
    timeSlot: '18:00-19:00',
    duration: 1,
    totalPrice: 1500,
    status: 'confirmed',
    createdAt: '2025-01-15T10:00:00Z'
  }
];

export const mockReviews: Review[] = [
  {
    id: '1',
    turfId: '1',
    userId: '1',
    userName: 'John Doe',
    rating: 5,
    comment: 'Excellent facilities and well-maintained turf. Highly recommended!',
    date: '2025-01-10'
  },
  {
    id: '2',
    turfId: '1',
    userId: '2',
    userName: 'Mike Johnson',
    rating: 4,
    comment: 'Good quality turf, but parking could be better.',
    date: '2025-01-08'
  }
];