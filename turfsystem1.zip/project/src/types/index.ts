export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: 'player' | 'owner';
  avatar?: string;
}

export interface Turf {
  id: string;
  name: string;
  location: string;
  description: string;
  images: string[];
  sports: string[];
  amenities: string[];
  pricePerHour: number;
  availableHours: {
    start: string;
    end: string;
  };
  rating: number;
  totalReviews: number;
  ownerId: string;
  equipmentRental: {
    available: boolean;
    items: EquipmentItem[];
  };
  events: Event[];
}

export interface EquipmentItem {
  id: string;
  name: string;
  price: number;
  available: number;
}

export interface Event {
  id: string;
  title: string;
  date: string;
  description: string;
  price?: number;
}

export interface Booking {
  id: string;
  turfId: string;
  userId: string;
  date: string;
  timeSlot: string;
  duration: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  paymentId?: string;
  equipmentRental?: {
    items: { id: string; quantity: number }[];
    totalPrice: number;
  };
  createdAt: string;
}

export interface Review {
  id: string;
  turfId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Payment {
  id: string;
  bookingId: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  method: 'card' | 'upi' | 'wallet';
  createdAt: string;
}

export interface FilterOptions {
  location: string;
  sports: string[];
  amenities: string[];
  priceRange: [number, number];
  rating: number;
}

export interface TimeSlot {
  time: string;
  available: boolean;
  price: number;
}