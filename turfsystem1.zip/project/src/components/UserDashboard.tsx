import React, { useState, useMemo } from 'react';
import { Calendar, Clock, MapPin, IndianRupee, Filter, Star, Trophy, X, CheckCircle, XCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface UserDashboardProps {
  onNavigate: (page: string, turfId?: string) => void;
}

const UserDashboard: React.FC<UserDashboardProps> = ({ onNavigate }) => {
  const { state, dispatch } = useApp();
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');
  const [selectedBooking, setSelectedBooking] = useState<string | null>(null);

  const userBookings = useMemo(() => {
    if (!state.user) return [];
    return state.bookings.filter(booking => booking.userId === state.user.id);
  }, [state.bookings, state.user]);

  const categorizedBookings = useMemo(() => {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    return {
      upcoming: userBookings.filter(booking => 
        booking.status === 'confirmed' && booking.date >= today
      ),
      past: userBookings.filter(booking => 
        booking.status === 'completed' || (booking.status === 'confirmed' && booking.date < today)
      ),
      cancelled: userBookings.filter(booking => booking.status === 'cancelled')
    };
  }, [userBookings]);

  const handleCancelBooking = (bookingId: string) => {
    const updatedBooking = userBookings.find(b => b.id === bookingId);
    if (updatedBooking) {
      dispatch({
        type: 'UPDATE_BOOKING',
        payload: { ...updatedBooking, status: 'cancelled' }
      });
      setSelectedBooking(null);
    }
  };

  const getTurfById = (turfId: string) => {
    return state.turfs.find(turf => turf.id === turfId);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'cancelled':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-blue-500" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      default:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
    }
  };

  const renderBookings = (bookings: typeof userBookings) => {
    if (bookings.length === 0) {
      return (
        <div className="text-center py-12">
          <div className="text-gray-400 dark:text-gray-600 text-6xl mb-4">📅</div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            No bookings found
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {activeTab === 'upcoming' ? "You don't have any upcoming bookings" : 
             activeTab === 'past' ? "You don't have any past bookings" :
             "You don't have any cancelled bookings"}
          </p>
          {activeTab === 'upcoming' && (
            <button
              onClick={() => onNavigate('turfs')}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Book a Turf
            </button>
          )}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {bookings.map(booking => {
          const turf = getTurfById(booking.turfId);
          if (!turf) return null;

          return (
            <div
              key={booking.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      {turf.name}
                    </h3>
                    <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                      {getStatusIcon(booking.status)}
                      <span className="capitalize">{booking.status}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm mb-2">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{turf.location}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center text-gray-600 dark:text-gray-400">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>{new Date(booking.date).toLocaleDateString()}</span>
                    </div>
                    
                    <div className="flex items-center text-gray-600 dark:text-gray-400">
                      <Clock className="h-4 w-4 mr-2" />
                      <span>{booking.timeSlot}</span>
                    </div>
                    
                    <div className="flex items-center text-green-600 dark:text-green-400 font-medium">
                      <IndianRupee className="h-4 w-4 mr-1" />
                      <span>{booking.totalPrice}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <button
                    onClick={() => onNavigate('turf-details', turf.id)}
                    className="px-3 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    View Turf
                  </button>
                  
                  {booking.status === 'confirmed' && activeTab === 'upcoming' && (
                    <button
                      onClick={() => setSelectedBooking(booking.id)}
                      className="px-3 py-1 text-sm bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                    >
                      Cancel
                    </button>
                  )}
                  
                  {booking.status === 'completed' && (
                    <button
                      onClick={() => onNavigate('turf-details', turf.id)}
                      className="flex items-center space-x-1 px-3 py-1 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                    >
                      <Star className="h-4 w-4" />
                      <span>Review</span>
                    </button>
                  )}
                </div>
              </div>
              
              {booking.equipmentRental && (
                <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Equipment Rental</h4>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    <span>Items rented • Total: ₹{booking.equipmentRental.totalPrice}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            My Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Manage your bookings and account settings
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Upcoming Bookings</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {categorizedBookings.upcoming.length}
                </p>
              </div>
              <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                <Calendar className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Bookings</p>
                <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {userBookings.length}
                </p>
              </div>
              <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Trophy className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Spent</p>
                <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                  ₹{userBookings.reduce((sum, booking) => sum + booking.totalPrice, 0)}
                </p>
              </div>
              <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <IndianRupee className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="border-b border-gray-200 dark:border-gray-700">
            <nav className="flex space-x-8 px-6">
              {[
                { key: 'upcoming', label: 'Upcoming', count: categorizedBookings.upcoming.length },
                { key: 'past', label: 'Past', count: categorizedBookings.past.length },
                { key: 'cancelled', label: 'Cancelled', count: categorizedBookings.cancelled.length }
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.key
                      ? 'border-green-500 text-green-600 dark:text-green-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  {tab.label} ({tab.count})
                </button>
              ))}
            </nav>
          </div>
          
          <div className="p-6">
            {renderBookings(categorizedBookings[activeTab])}
          </div>
        </div>

        {/* Cancel Booking Modal */}
        {selectedBooking && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Cancel Booking
                </h3>
                <button
                  onClick={() => setSelectedBooking(null)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Are you sure you want to cancel this booking? This action cannot be undone.
              </p>
              
              <div className="flex space-x-4">
                <button
                  onClick={() => setSelectedBooking(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Keep Booking
                </button>
                <button
                  onClick={() => handleCancelBooking(selectedBooking)}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Cancel Booking
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;