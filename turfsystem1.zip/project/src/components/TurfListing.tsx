import React, { useState, useMemo } from 'react';
import { Search, Filter, MapPin, Star, Clock, IndianRupee, Wifi, Car, Users, Lightbulb } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FilterOptions } from '../types';
import TurfCard from './TurfCard';

interface TurfListingProps {
  onNavigate: (page: string, turfId?: string) => void;
}

const TurfListing: React.FC<TurfListingProps> = ({ onNavigate }) => {
  const { state } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    location: '',
    sports: [],
    amenities: [],
    priceRange: [0, 3000],
    rating: 0,
  });

  const allSports = ['Football', 'Cricket', 'Basketball', 'Badminton', 'Tennis'];
  const allAmenities = ['Parking', 'Changing Room', 'Washroom', 'Floodlights', 'Water', 'AC Rooms', 'Cafeteria', 'First Aid'];
  const allLocations = [...new Set(state.turfs.map(turf => turf.location))];

  const filteredTurfs = useMemo(() => {
    return state.turfs.filter(turf => {
      const matchesSearch = turf.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          turf.location.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesLocation = !filters.location || turf.location.includes(filters.location);
      
      const matchesSports = filters.sports.length === 0 || 
                          filters.sports.some(sport => turf.sports.includes(sport));
      
      const matchesAmenities = filters.amenities.length === 0 ||
                             filters.amenities.every(amenity => turf.amenities.includes(amenity));
      
      const matchesPrice = turf.pricePerHour >= filters.priceRange[0] && 
                          turf.pricePerHour <= filters.priceRange[1];
      
      const matchesRating = turf.rating >= filters.rating;

      return matchesSearch && matchesLocation && matchesSports && matchesAmenities && matchesPrice && matchesRating;
    });
  }, [state.turfs, searchTerm, filters]);

  const handleSportToggle = (sport: string) => {
    setFilters(prev => ({
      ...prev,
      sports: prev.sports.includes(sport)
        ? prev.sports.filter(s => s !== sport)
        : [...prev.sports, sport]
    }));
  };

  const handleAmenityToggle = (amenity: string) => {
    setFilters(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const clearFilters = () => {
    setFilters({
      location: '',
      sports: [],
      amenities: [],
      priceRange: [0, 3000],
      rating: 0,
    });
  };

  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case 'Parking': return <Car className="h-4 w-4" />;
      case 'Changing Room': return <Users className="h-4 w-4" />;
      case 'Floodlights': return <Lightbulb className="h-4 w-4" />;
      case 'Cafeteria': return <Users className="h-4 w-4" />;
      default: return <Wifi className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Find Your Perfect Turf
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Discover and book premium quality turfs in your area
          </p>
        </div>

        {/* Search and Filter Bar */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search by turf name or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-6 py-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <Filter className="h-5 w-5" />
              <span>Filters</span>
              {(filters.sports.length > 0 || filters.amenities.length > 0 || filters.location || filters.rating > 0) && (
                <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                  {filters.sports.length + filters.amenities.length + (filters.location ? 1 : 0) + (filters.rating > 0 ? 1 : 0)}
                </span>
              )}
            </button>
          </div>

          {/* Filters Panel */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Location Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Location
                  </label>
                  <select
                    value={filters.location}
                    onChange={(e) => setFilters(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="">All Locations</option>
                    {allLocations.map(location => (
                      <option key={location} value={location}>{location}</option>
                    ))}
                  </select>
                </div>

                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Price Range (per hour)
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="3000"
                      step="100"
                      value={filters.priceRange[1]}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        priceRange: [0, parseInt(e.target.value)]
                      }))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span>₹0</span>
                      <span>₹{filters.priceRange[1]}</span>
                    </div>
                  </div>
                </div>

                {/* Rating Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Minimum Rating
                  </label>
                  <select
                    value={filters.rating}
                    onChange={(e) => setFilters(prev => ({ ...prev, rating: parseFloat(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="0">Any Rating</option>
                    <option value="3">3+ Stars</option>
                    <option value="4">4+ Stars</option>
                    <option value="4.5">4.5+ Stars</option>
                  </select>
                </div>

                {/* Clear Filters */}
                <div className="flex items-end">
                  <button
                    onClick={clearFilters}
                    className="w-full px-4 py-2 text-red-600 border border-red-300 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  >
                    Clear All
                  </button>
                </div>
              </div>

              {/* Sports Filter */}
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Sports
                </label>
                <div className="flex flex-wrap gap-2">
                  {allSports.map(sport => (
                    <button
                      key={sport}
                      onClick={() => handleSportToggle(sport)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                        filters.sports.includes(sport)
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      {sport}
                    </button>
                  ))}
                </div>
              </div>

              {/* Amenities Filter */}
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Amenities
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {allAmenities.map(amenity => (
                    <button
                      key={amenity}
                      onClick={() => handleAmenityToggle(amenity)}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                        filters.amenities.includes(amenity)
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      {getAmenityIcon(amenity)}
                      <span>{amenity}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results */}
        <div className="mb-6">
          <p className="text-gray-600 dark:text-gray-400">
            Showing {filteredTurfs.length} of {state.turfs.length} turfs
          </p>
        </div>

        {/* Turf Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTurfs.map(turf => (
            <TurfCard
              key={turf.id}
              turf={turf}
              onBookNow={() => onNavigate('booking', turf.id)}
              onViewDetails={() => onNavigate('turf-details', turf.id)}
            />
          ))}
        </div>

        {filteredTurfs.length === 0 && (
          <div className="text-center py-16">
            <div className="text-gray-400 dark:text-gray-600 text-6xl mb-4">🏟️</div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              No turfs found
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Try adjusting your search criteria or filters
            </p>
            <button
              onClick={clearFilters}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TurfListing;