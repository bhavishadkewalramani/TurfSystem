import React from 'react';
import { MapPin, Star, Clock, IndianRupee, Car, Users, Lightbulb, Trophy } from 'lucide-react';
import { Turf } from '../types';

interface TurfCardProps {
  turf: Turf;
  onBookNow: () => void;
  onViewDetails: () => void;
}

const TurfCard: React.FC<TurfCardProps> = ({ turf, onBookNow, onViewDetails }) => {
  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case 'Parking': return <Car className="h-4 w-4" />;
      case 'Changing Room': return <Users className="h-4 w-4" />;
      case 'Floodlights': return <Lightbulb className="h-4 w-4" />;
      default: return <Users className="h-4 w-4" />;
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={turf.images[0]}
          alt={turf.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4 bg-white dark:bg-gray-800 rounded-full px-2 py-1 flex items-center space-x-1">
          <Star className="h-4 w-4 text-yellow-500 fill-current" />
          <span className="text-sm font-medium text-gray-900 dark:text-white">{turf.rating}</span>
        </div>
        {turf.events.length > 0 && (
          <div className="absolute top-4 left-4 bg-orange-500 text-white rounded-full px-2 py-1 flex items-center space-x-1">
            <Trophy className="h-4 w-4" />
            <span className="text-xs font-medium">Events</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="mb-3">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1 line-clamp-1">
            {turf.name}
          </h3>
          <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="line-clamp-1">{turf.location}</span>
          </div>
        </div>

        {/* Sports */}
        <div className="mb-3">
          <div className="flex flex-wrap gap-1">
            {turf.sports.slice(0, 3).map(sport => (
              <span
                key={sport}
                className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 text-xs rounded-full"
              >
                {sport}
              </span>
            ))}
            {turf.sports.length > 3 && (
              <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded-full">
                +{turf.sports.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* Amenities */}
        <div className="mb-4">
          <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400">
            {turf.amenities.slice(0, 4).map(amenity => (
              <div key={amenity} className="flex items-center" title={amenity}>
                {getAmenityIcon(amenity)}
              </div>
            ))}
            {turf.amenities.length > 4 && (
              <span className="text-xs text-gray-400">+{turf.amenities.length - 4}</span>
            )}
          </div>
        </div>

        {/* Price and Hours */}
        <div className="mb-4 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center text-green-600 dark:text-green-400">
              <IndianRupee className="h-4 w-4" />
              <span className="font-bold text-lg">{turf.pricePerHour}</span>
              <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">/hour</span>
            </div>
            <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
              <Clock className="h-4 w-4 mr-1" />
              <span>{turf.availableHours.start} - {turf.availableHours.end}</span>
            </div>
          </div>
          
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            <span>{turf.totalReviews} reviews</span>
            {turf.equipmentRental.available && (
              <>
                <span className="mx-2">•</span>
                <span>Equipment available</span>
              </>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-3">
          <button
            onClick={onViewDetails}
            className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm font-medium"
          >
            View Details
          </button>
          <button
            onClick={onBookNow}
            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
          >
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default TurfCard;