import React from 'react';
import { MapPin, Calendar, Star, Clock, Shield, Trophy } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { state } = useApp();

  const features = [
    {
      icon: <Calendar className="h-8 w-8 text-green-600" />,
      title: 'Easy Booking',
      description: 'Book your favorite turf in just a few clicks with real-time availability.'
    },
    {
      icon: <MapPin className="h-8 w-8 text-blue-600" />,
      title: 'Multiple Locations',
      description: 'Find turfs near you with our comprehensive location search.'
    },
    {
      icon: <Shield className="h-8 w-8 text-purple-600" />,
      title: 'Secure Payments',
      description: 'Safe and secure payment processing with multiple payment options.'
    },
    {
      icon: <Star className="h-8 w-8 text-yellow-600" />,
      title: 'Reviews & Ratings',
      description: 'Read authentic reviews and ratings from the community.'
    },
    {
      icon: <Clock className="h-8 w-8 text-red-600" />,
      title: '24/7 Availability',
      description: 'Book slots anytime with our round-the-clock booking system.'
    },
    {
      icon: <Trophy className="h-8 w-8 text-orange-600" />,
      title: 'Events & Tournaments',
      description: 'Join exciting tournaments and community events.'
    }
  ];

  const stats = [
    { label: 'Active Turfs', value: '50+' },
    { label: 'Happy Customers', value: '1000+' },
    { label: 'Cities Covered', value: '15+' },
    { label: 'Bookings Made', value: '5000+' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Book Your Perfect Turf
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90">
              Find and book premium quality turfs for football, cricket, and more sports
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('turfs')}
                className="bg-white text-green-600 font-semibold py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors transform hover:scale-105"
              >
                Browse Turfs
              </button>
              
              {state.user?.role === 'owner' && (
                <button
                  onClick={() => onNavigate('admin')}
                  className="border-2 border-white text-white font-semibold py-3 px-8 rounded-lg hover:bg-white hover:text-green-600 transition-colors transform hover:scale-105"
                >
                  Manage Your Turfs
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-white dark:bg-gray-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-green-600 dark:text-green-400 mb-2">
                  {stat.value}
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Why Choose TurfBook?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Everything you need for the perfect turf booking experience
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-green-600 dark:bg-green-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Join thousands of players who trust TurfBook for their sports needs
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('turfs')}
              className="bg-white text-green-600 font-semibold py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors transform hover:scale-105"
            >
              Find Turfs Now
            </button>
            
            <button
              onClick={() => onNavigate('dashboard')}
              className="border-2 border-white text-white font-semibold py-3 px-8 rounded-lg hover:bg-white hover:text-green-600 transition-colors transform hover:scale-105"
            >
              My Dashboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;