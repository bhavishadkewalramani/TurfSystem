import React, { useState, useMemo } from 'react';
import { Calendar, Clock, IndianRupee, Users, ArrowLeft, CreditCard, Smartphone, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TimeSlot, Booking } from '../types';

interface BookingPageProps {
  turfId: string;
  onNavigate: (page: string) => void;
}

const BookingPage: React.FC<BookingPageProps> = ({ turfId, onNavigate }) => {
  const { state, dispatch } = useApp();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  const [duration, setDuration] = useState(1);
  const [selectedEquipment, setSelectedEquipment] = useState<{[key: string]: number}>({});
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'wallet'>('card');
  const [showPayment, setShowPayment] = useState(false);
  const [paymentProcessing, setPaymentProcessing] = useState(false);

  const turf = state.turfs.find(t => t.id === turfId);

  const timeSlots = useMemo(() => {
    if (!turf) return [];
    
    const slots: TimeSlot[] = [];
    const startHour = parseInt(turf.availableHours.start.split(':')[0]);
    const endHour = parseInt(turf.availableHours.end.split(':')[0]);
    
    for (let hour = startHour; hour < endHour; hour++) {
      const timeString = `${hour.toString().padStart(2, '0')}:00-${(hour + 1).toString().padStart(2, '0')}:00`;
      
      // Check if slot is already booked
      const isBooked = state.bookings.some(booking => 
        booking.turfId === turfId && 
        booking.date === selectedDate && 
        booking.timeSlot === timeString &&
        booking.status !== 'cancelled'
      );
      
      slots.push({
        time: timeString,
        available: !isBooked,
        price: turf.pricePerHour
      });
    }
    
    return slots;
  }, [turf, turfId, selectedDate, state.bookings]);

  const totalEquipmentPrice = useMemo(() => {
    if (!turf) return 0;
    return Object.entries(selectedEquipment).reduce((total, [itemId, quantity]) => {
      const item = turf.equipmentRental.items.find(i => i.id === itemId);
      return total + (item ? item.price * quantity : 0);
    }, 0);
  }, [selectedEquipment, turf]);

  const totalPrice = useMemo(() => {
    if (!turf || !selectedTimeSlot) return 0;
    return (turf.pricePerHour * duration) + totalEquipmentPrice;
  }, [turf, duration, totalEquipmentPrice, selectedTimeSlot]);

  if (!turf) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Turf Not Found</h2>
          <button
            onClick={() => onNavigate('turfs')}
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            Browse Turfs
          </button>
        </div>
      </div>
    );
  }

  const handleEquipmentChange = (itemId: string, quantity: number) => {
    setSelectedEquipment(prev => ({
      ...prev,
      [itemId]: Math.max(0, quantity)
    }));
  };

  const handleBooking = () => {
    if (!selectedTimeSlot || !state.user) return;
    setShowPayment(true);
  };

  const processPayment = async () => {
    if (!state.user) return;
    
    setPaymentProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newBooking: Booking = {
      id: Date.now().toString(),
      turfId: turf.id,
      userId: state.user.id,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      duration,
      totalPrice,
      status: 'confirmed',
      paymentId: `pay_${Date.now()}`,
      equipmentRental: Object.keys(selectedEquipment).length > 0 ? {
        items: Object.entries(selectedEquipment).map(([id, quantity]) => ({ id, quantity })),
        totalPrice: totalEquipmentPrice
      } : undefined,
      createdAt: new Date().toISOString()
    };

    dispatch({ type: 'ADD_BOOKING', payload: newBooking });
    setPaymentProcessing(false);
    setShowPayment(false);
    
    // Navigate to success page or dashboard
    onNavigate('dashboard');
  };

  const getNextDays = (numDays: number) => {
    const days = [];
    for (let i = 0; i < numDays; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      days.push(date);
    }
    return days;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => onNavigate('turf-details', turfId)}
            className="mr-4 p-2 rounded-lg bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow"
          >
            <ArrowLeft className="h-6 w-6 text-gray-600 dark:text-gray-400" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Book {turf.name}
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Select your preferred date and time
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Date Selection */}
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Select Date
              </h3>
              
              <div className="grid grid-cols-7 gap-2">
                {getNextDays(14).map((date, index) => {
                  const dateString = date.toISOString().split('T')[0];
                  const isSelected = selectedDate === dateString;
                  const isToday = index === 0;
                  
                  return (
                    <button
                      key={dateString}
                      onClick={() => setSelectedDate(dateString)}
                      className={`p-3 rounded-lg text-center transition-colors ${
                        isSelected
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      <div className="text-xs font-medium">
                        {date.toLocaleDateString('en', { weekday: 'short' })}
                      </div>
                      <div className="text-sm font-bold">
                        {date.getDate()}
                      </div>
                      {isToday && (
                        <div className="text-xs text-green-600 dark:text-green-400 font-medium">
                          Today
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Slot Selection */}
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Select Time Slot
              </h3>
              
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {timeSlots.map((slot) => (
                  <button
                    key={slot.time}
                    onClick={() => slot.available && setSelectedTimeSlot(slot.time)}
                    disabled={!slot.available}
                    className={`p-3 rounded-lg text-center transition-colors ${
                      selectedTimeSlot === slot.time
                        ? 'bg-green-600 text-white'
                        : slot.available
                        ? 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                        : 'bg-gray-50 dark:bg-gray-800 text-gray-400 dark:text-gray-600 cursor-not-allowed'
                    }`}
                  >
                    <div className="text-sm font-medium">
                      {slot.time}
                    </div>
                    <div className="text-xs">
                      {slot.available ? `₹${slot.price}` : 'Booked'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Duration Selection */}
            {selectedTimeSlot && (
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Duration
                </h3>
                
                <div className="flex space-x-4">
                  {[1, 2, 3, 4].map((hours) => (
                    <button
                      key={hours}
                      onClick={() => setDuration(hours)}
                      className={`px-4 py-2 rounded-lg transition-colors ${
                        duration === hours
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      {hours} Hour{hours > 1 ? 's' : ''}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Equipment Rental */}
            {turf.equipmentRental.available && turf.equipmentRental.items.length > 0 && (
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Equipment Rental (Optional)
                </h3>
                
                <div className="space-y-4">
                  {turf.equipmentRental.items.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-white">{item.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">₹{item.price} per item</p>
                        <p className="text-xs text-gray-500 dark:text-gray-500">{item.available} available</p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleEquipmentChange(item.id, (selectedEquipment[item.id] || 0) - 1)}
                          className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-gray-300 dark:hover:bg-gray-500"
                        >
                          -
                        </button>
                        <span className="w-8 text-center font-medium text-gray-900 dark:text-white">
                          {selectedEquipment[item.id] || 0}
                        </span>
                        <button
                          onClick={() => handleEquipmentChange(item.id, (selectedEquipment[item.id] || 0) + 1)}
                          disabled={(selectedEquipment[item.id] || 0) >= item.available}
                          className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-gray-300 dark:hover:bg-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Booking Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700 sticky top-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Booking Summary
              </h3>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Turf</span>
                  <span className="font-medium text-gray-900 dark:text-white">{turf.name}</span>
                </div>
                
                {selectedDate && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Date</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {new Date(selectedDate).toLocaleDateString()}
                    </span>
                  </div>
                )}
                
                {selectedTimeSlot && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Time</span>
                    <span className="font-medium text-gray-900 dark:text-white">{selectedTimeSlot}</span>
                  </div>
                )}
                
                {selectedTimeSlot && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Duration</span>
                    <span className="font-medium text-gray-900 dark:text-white">{duration} hour{duration > 1 ? 's' : ''}</span>
                  </div>
                )}
              </div>
              
              {selectedTimeSlot && (
                <>
                  <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600 dark:text-gray-400">Turf charges</span>
                      <span className="text-gray-900 dark:text-white">₹{turf.pricePerHour * duration}</span>
                    </div>
                    
                    {totalEquipmentPrice > 0 && (
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-600 dark:text-gray-400">Equipment rental</span>
                        <span className="text-gray-900 dark:text-white">₹{totalEquipmentPrice}</span>
                      </div>
                    )}
                    
                    <div className="flex justify-between text-lg font-semibold border-t border-gray-200 dark:border-gray-700 pt-2">
                      <span className="text-gray-900 dark:text-white">Total</span>
                      <span className="text-green-600 dark:text-green-400">₹{totalPrice}</span>
                    </div>
                  </div>
                  
                  <button
                    onClick={handleBooking}
                    className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors font-medium"
                  >
                    Book Now
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Payment Modal */}
        {showPayment && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Payment Details
              </h3>
              
              <div className="mb-6">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600 dark:text-gray-400">Total Amount</span>
                  <span className="text-2xl font-bold text-green-600 dark:text-green-400">₹{totalPrice}</span>
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Payment Method</h4>
                <div className="space-y-2">
                  {[
                    { id: 'card', label: 'Credit/Debit Card', icon: <CreditCard className="h-5 w-5" /> },
                    { id: 'upi', label: 'UPI', icon: <Smartphone className="h-5 w-5" /> },
                    { id: 'wallet', label: 'Wallet', icon: <Wallet className="h-5 w-5" /> }
                  ].map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setPaymentMethod(method.id as any)}
                      className={`w-full flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
                        paymentMethod === method.id
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                          : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                      }`}
                    >
                      {method.icon}
                      <span className="text-gray-900 dark:text-white">{method.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowPayment(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={processPayment}
                  disabled={paymentProcessing}
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center justify-center"
                >
                  {paymentProcessing ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    'Pay Now'
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BookingPage;