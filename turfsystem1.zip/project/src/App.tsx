import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import Header from './components/Header';
import AuthPage from './components/AuthPage';
import HomePage from './components/HomePage';
import TurfListing from './components/TurfListing';
import UserDashboard from './components/UserDashboard';
import BookingPage from './components/BookingPage';

function AppContent() {
  const [currentPage, setCurrentPage] = useState('auth');
  const [selectedTurfId, setSelectedTurfId] = useState<string | null>(null);

  const handleNavigate = (page: string, turfId?: string) => {
    setCurrentPage(page);
    if (turfId) {
      setSelectedTurfId(turfId);
    }
  };

  const handleAuthSuccess = () => {
    setCurrentPage('home');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'auth':
        return <AuthPage onSuccess={handleAuthSuccess} />;
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'turfs':
        return <TurfListing onNavigate={handleNavigate} />;
      case 'dashboard':
        return <UserDashboard onNavigate={handleNavigate} />;
      case 'booking':
        return selectedTurfId ? (
          <BookingPage turfId={selectedTurfId} onNavigate={handleNavigate} />
        ) : (
          <div>No turf selected</div>
        );
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      <main>{renderPage()}</main>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;